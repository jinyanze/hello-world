<template>
	<view class="">
		<!-- <yjCard :avatarInfo="avatarInfo" @cardCallback="cardCallback"></yjCard>
		<view style="font-size: 40rpx;margin-left: 40rpx;" @click="popup = true;">签名</view>
		<view style="font-size: 40rpx;margin-left: 40rpx;" @click="openMaterial = true;">选择材料</view>
		<yjMaterial :show="openMaterial" @confirmCallback="confirmCallback"></yjMaterial>
		<view class="" v-if="isShowCard" style="border: 1rpx solid black;">
			<u-swipe-action>
				<u-swipe-action-item :options="options1" @click="closeCard">
					<view class="swipe-action u-border-top u-border-bottom">
						<view class="swipe-action__content">
							<view class="" style="height: 80rpx;line-height: 80rpx;">
								物料一: 右键删除
							</view>
						</view>
					</view>
				</u-swipe-action-item>
			</u-swipe-action>
			<view>
				<view class="">
					111111111111
				</view>
				<view class="">
					222222222222
				</view>
			</view>
		</view>
		<view style="font-size: 40rpx;margin-left: 40rpx;" @click="getQrcode">生成二维码</view>
		<view style="font-size: 40rpx;margin-left: 40rpx;" @click="scanCode">扫码</view>
		<view style="font-size: 40rpx;margin-left: 40rpx;" @click="getImageInfo">获取图片信息</view>
		图片最后修改时间(拍摄时间)<uni-dateformat :date="date"></uni-dateformat> -->

		<mescroll-body @init="mescrollInit" @down="downCallback" @up="upCallback">
			<!-- // @init="mescrollInit" @down="downCallback" @up="upCallback"为固定值,不可删改(与mescroll-mixins保持一致)
			// :down="downOption" :up="upOption" 绝大部分情况无需配置
			// :top="顶部偏移量" :bottom="底部偏移量" :topbar="状态栏" :safearea="安全区" (常用)
			// 此处支持写入原生组件 -->
			<u-cell v-for='(item,index) in indexList' :title="`列表长度-${index + 1}`">
				<u-avatar slot="icon" shape="square" size="35" :src="item.url"
					customStyle="margin: -3px 5px -3px 0"></u-avatar>
			</u-cell>
		</mescroll-body>

		<!--   -->

		<yjGetUqrcode ref="yjGetUqrcode" :size="'100'" v-if="isShowQrcode" :qrCodeInfo="qrCodeInfo"
			:isVisibility="false" @getQrCodeUrl="getQrCodeUrl"></yjGetUqrcode>
		<image :src="signatureUrl" mode=""></image>
		<u-popup :show="popup" mode="center" width="100%">
			<yjSignature @saved="savedSign" ref="signatureRef" @closed="closeSignPop"></yjSignature>
		</u-popup>
	</view>
</template>

<script>
	// 卡片
	import yjCard from './yj-card.vue';
	// 生成二维码
	import yjGetUqrcode from './yj-getUqrcode'
	// 签名
	import yjSignature from './yj-signature'
	// 选择材质
	import yjMaterial from './yj-material'
	// import localforage from 'localforage'

	//引入扫码的方法
	import qrcode from "./qrcode.js";

	import MescrollMixin from "@/uni_modules/mescroll-uni/components/mescroll-uni/mescroll-mixins.js";

	var mpaasScanModule = uni.requireNativePlugin("Mpaas-Scan-Module")

	import {
		warn
	} from "vue";
	export default {
		data() {
			return {
				avatarInfo: {
					url: require('./img.png'),
					name: '张三'
				},
				popup: false,
				openMaterial: false,
				isShowCard: true,
				isShowQrcode: false,
				qrCodeInfo: {
					mechanicalCode: '这是机械代码',
					largeHanger: '这是大架号'
				},
				options1: [{
					text: '删除'
				}],
				date: null,
				signatureUrl: '',

				indexList: [],
				urls: [
					'https://cdn.uviewui.com/uview/album/1.jpg',
					'https://cdn.uviewui.com/uview/album/2.jpg',
					'https://cdn.uviewui.com/uview/album/3.jpg',
					'https://cdn.uviewui.com/uview/album/4.jpg',
					'https://cdn.uviewui.com/uview/album/5.jpg',
					'https://cdn.uviewui.com/uview/album/6.jpg',
					'https://cdn.uviewui.com/uview/album/7.jpg',
					'https://cdn.uviewui.com/uview/album/8.jpg',
					'https://cdn.uviewui.com/uview/album/9.jpg',
					'https://cdn.uviewui.com/uview/album/10.jpg',
				],
				totalPage: 1,
			}
		},
		components: {
			yjCard,
			yjSignature,
			yjMaterial,
			yjGetUqrcode
		},
		onLoad() {
			this.loadmore()
		},
		methods: {
			mescrollInit() {

			},
			downCallback() {
				this.loadmore();
				
				this.mescroll.endByPage(30, 6);
			},
			upCallback() {
				console.log('aaaaaaaaa');
			},
			loadmore() {
				for (let i = 0; i < 30; i++) {
					this.indexList.push({
						url: this.urls[uni.$u.random(0, this.urls.length - 1)]
					})
				}
			},
			// 获取图片信息
			getImageInfo() {
				uni.chooseImage({
					count: 1,
					sourceType: ['album', 'camera'],
					sizeType: ['original'],
					success: (res) => {
						// 图片最后修改时间 不支持h5 在res中有h5的最后修改时间
						plus.io.resolveLocalFileSystemURL(res.tempFilePaths[0], (entry) => {
							entry.file((file) => {
								var fileReader = new plus.io.FileReader();
								console.log("getFile:" + JSON.stringify(file));
								this.date = file.lastModifiedDate;
							});
						}, (e) => {
							console.log("Resolve file URL failed: " + e.message);
						});
					}
				});
			},
			// 扫码
			scanCode() {
				let flag = false;
				mpaasScanModule.mpaasScan({
						// 扫码识别类型，参数可多选，qrCode、barCode，不设置，默认识别所有
						'scanType': ['qrCode', 'barCode'],
						// 是否隐藏相册，默认false不隐藏
						'hideAlbum': false
					},
					(res) => {
						console.log('aaa', res);
					})
			},
			// 解码中文乱码
			decodeStr(str) {
				var out, i, len, c;
				var char2, char3;
				out = "";
				len = str.length;
				i = 0;
				while (i < len) {
					c = str.charCodeAt(i++);
					switch (c >> 4) {
						case 0:
						case 1:
						case 2:
						case 3:
						case 4:
						case 5:
						case 6:
						case 7:
							// 0xxxxxxx
							out += str.charAt(i - 1);
							break;
						case 12:
						case 13:
							// 110x xxxx 10xx xxxx
							char2 = str.charCodeAt(i++);
							out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
							break;
						case 14:
							// 1110 xxxx 10xx xxxx 10xx xxxx
							char2 = str.charCodeAt(i++);
							char3 = str.charCodeAt(i++);
							out += String.fromCharCode(((c & 0x0F) << 12) |
								((char2 & 0x3F) << 6) |
								((char3 & 0x3F) << 0));
							break;
					}
				}
				return out;
			},
			// 打开qrcode子组件
			getQrcode() {
				this.isShowQrcode = true;
				let qrcodeUrl = ''
				this.$nextTick(() => {
					qrcodeUrl = this.$refs.yjGetUqrcode.getQrcode();
				})
			},
			// 获得临时二维码图片链接
			getQrCodeUrl(res) {
				console.log('二维码临时图片地址', res);
			},
			closeCard() {
				this.isShowCard = false;
				console.log('删除卡片');
			},
			cardCallback(type) {
				console.log('卡片组件点击后事件', type);
			},
			savedSign(res) {
				this.popup = false;
				// console.log('aaaaa',res);
				this.signatureUrl = res;
				this.$nextTick(() => {
					this.$u.toast('保存成功')
				})
			},
			closeSignPop(error) {
				this.popup = false;
			},
			confirmCallback(res) {
				console.log('选择材质后', res);
				this.openMaterial = false;
			}
		}
	}
</script>

<style>
</style>